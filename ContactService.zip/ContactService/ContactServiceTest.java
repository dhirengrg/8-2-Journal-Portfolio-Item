package ContactService;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContactServiceTest {
ContactService contactService = new ContactService();
    @Test
    void contactAdd() {
        Contact one = new Contact("11","Nisha","Rai","987654321","147 Northern");
        assertEquals(true, contactService.contactAdd(one));
    }

    @Test
    void contactDelete() {
        Contact two = new Contact("11","Nisha","Rai","987654321","147 Northern");
        assertEquals(false,contactService.contactDelete("11"));
    }

    @Test
    void contactUpdate() {
        Contact three = new Contact("12","Manju", "Sherpa","123123123","huntington");
        assertEquals(false, contactService.contactUpdate("12","Amber","Gurung","567568568","nepal"));

    }
}