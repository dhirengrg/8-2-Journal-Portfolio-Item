package ContactService;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContactTest {
    Contact contact = new Contact("10", "Dhiren","Gurung","123456789","14703 Northern Blvd");
    @Test
    void getContactID() {
        assertEquals("10", contact.getContactID());
    }

    @Test
    void getFirstName() {
        assertEquals("Dhiren",contact.getFirstName());
    }

    @Test
    void getLastName() {
        assertEquals("Gurung",contact.getLastName());
    }

    @Test
    void getPhone() {
        assertEquals("123456789",contact.getPhone());
    }

    @Test
    void getAddress() {
        assertEquals("14703 Northern Blvd", contact.getAddress());
    }
}