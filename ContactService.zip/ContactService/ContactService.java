package ContactService;
import java.util.ArrayList;

public class ContactService {

    private ArrayList<Contact> ContactLists;

    public ContactService() {
        ContactLists = new ArrayList<>();
    }

    public boolean contactAdd(Contact n) {
        boolean contactExist = false;

        for(Contact list:ContactLists) {
            if(list.equals(n)) {
                contactExist = true;
            }
        }
        if(!contactExist) {
            ContactLists.add(n);
            return true;
        }
        else {
            return false;
        }
    }

    public boolean contactDelete(String contactID) {

        for(Contact list:ContactLists) {
            if(list.getContactID().equals(contactID)) {
                ContactLists.remove(list);
                return true;
            }
        }
        return false;

    }

    public boolean contactUpdate(String contactID, String firstName, String lastName, String number, String address) {
        for(Contact list:ContactLists) {
            if(list.getContactID().equals(contactID)) {
                if(!firstName.equals("") && (firstName.length() > 10)) {
                    list.setFirstName(firstName);
                }
                if(!lastName.equals("") && (lastName.length() > 10)) {
                    list.setLastName(lastName);
                }
                if(!number.equals("") && (number.length() > 10)) {
                    list.setPhone(number);
                }
                if(!address.equals("") && address.length() > 30) {
                    list.setAddress(address);
                }
                return true;
            }
        }
        return false;
    }
    }


