package ContactService;

public class Contact {
    private String contactID;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;
    public Contact (String contactID, String firstName, String lastName, String phone, String address){
        if (contactID.length() <=10 && contactID != null){
            this.contactID = contactID;
        }
        if (firstName.length() <= 10 && firstName != null){
            this.firstName = firstName;
        }
        if (lastName.length() <=10 && lastName != null){
            this.lastName = lastName;
        }
        if (phone.length() <=10 && phone !=null){
            this.phone = phone;
        }
        if (address.length() <=30 && address != null){
            this.address = address;
        }
    }
    // Getters
    public String getContactID() {
        return this.contactID;
    }
    public String getFirstName() {
        return this.firstName;
    }
    public String getLastName() {
        return this.lastName;
    }
    public String getPhone() {
        return this.phone;
    }
    public String getAddress() {
        return this.address;
    }
    // Setters
    public void setContactID(String contactId) {
        this.contactID = contactID;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public void setAddress(String address) {
        this.address = address;
    }
}
